package mil;

import java.util.Scanner;

public class Millionire {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int prize = 0;

		// first question
		System.out.println("Otázka za 1000 Kč.");
		System.out.println("Kdy byl vyvořen YouTube?");
		System.out.println("A) 2001 B) 2002");
		System.out.println("C) 2005 D) 2006");
		System.out.print("Zadej odpověd: ");

		String i = input.nextLine();
		boolean isRight = i.equals("c");
		if (isRight) {
			prize = prize + 1000;
			System.out.println("Správně!! Vyhráváte " +  String.valueOf(prize) + "Kč.");
			
			
			// second question
			System.out.println("Otázka za 2000 Kč");
			System.out.println("Jaká je přezdívka vývojáře Minecraftu Markuse Perssona?");
			System.out.println("A) Herobrine B) Notch");
			System.out.println("C) Dream D) Hacker4d");
			System.out.print("Zadej odpověd: ");

			i = input.nextLine();
			isRight = i.equals("b");
			if (isRight) {
				prize = prize + 2000;
				System.out.println("Správně!! Vyhráváte " +  String.valueOf(prize) + "Kč.");
				
				// third question
				System.out.println("Otázka za 3000 Kč");
				System.out.println("Jak se jmenuje hlavní postava z Zaklínače?");
				System.out.println("A) Geralt B) Ciri");
				System.out.println("C) Yennefer D) Jaskier");
				System.out.print("Zadej odpověd: ");

				i = input.nextLine();
				isRight = i.equals("a");
				if (isRight) {
					prize = prize + 3000;
					System.out.println("Správně!! Vyhráváte " +  String.valueOf(prize) + "Kč.");
					
					// fourth question
					System.out.println("Otázka za 5000 Kč");
					System.out.println("Jaká společnost vyrábý iPhone?");
					System.out.println("A) Android B) Huawei");
					System.out.println("C) Samsung D) Apple");
					System.out.print("Zadej odpověd: ");

					i = input.nextLine();
					isRight = i.equals("d");
					if (isRight) {
						prize = prize + 5000;
						System.out.println("Správně!! Vyhráváte " +  String.valueOf(prize) + "Kč.");
						
						// fifth question
						System.out.println("Otázka za 10000 Kč");
						System.out.println("Co znamená zkratka GPU?");
						System.out.println("A) procesor grafické karty B) hlavní procesor");
						System.out.println("C) grafická karta D) hard disk");
						System.out.print("Zadej odpověd: ");

						i = input.nextLine();
						isRight = i.equals("a");
						if (isRight) {
							prize = prize + 10000;
							System.out.println("Správně!! Vyhráváte " +  String.valueOf(prize) +  "Kč.");
						} else {
							System.out.println("Špatně. Bohužel pro vás hra končí. Přišel jste o " + String.valueOf(prize) + "Kč");
						}
						
					} else {
						System.out.println("Špatně. Bohužel pro vás hra končí. Přišel jste o " + String.valueOf(prize) + "Kč");
					}
					
				} else {
					System.out.println("Špatně. Bohužel pro vás hra končí. Přišel jste o " + String.valueOf(prize) + "Kč");
				}
				
			} else {
				System.out.println("Špatně. Bohužel pro vás hra končí. Přišel jste o " + String.valueOf(prize) + "Kč");
			}
			
		} else {
			System.out.println("Špatně. Bohužel pro vás hra končí. Přišel jste o " + String.valueOf(prize) + "Kč");
		}
		
		input.close();

	}

}
